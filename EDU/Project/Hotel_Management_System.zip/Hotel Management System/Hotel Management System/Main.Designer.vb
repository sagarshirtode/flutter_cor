<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.RoomInformationToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SetUpUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeUserNamePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RoomInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewAllRoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckOutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerInformationToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SetRoomPriceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RoomInformationToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.SecurityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeUserNamePasswordToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckOutToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton
        Me.TDate = New System.Windows.Forms.ToolStripLabel
        Me.TUser = New System.Windows.Forms.ToolStripLabel
        Me.ViewAllRoomToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LogOutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckInToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.BookingToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.CheckOutToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.SetUpUserToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RoomInformationToolStripMenuItem1
        '
        Me.RoomInformationToolStripMenuItem1.Name = "RoomInformationToolStripMenuItem1"
        Me.RoomInformationToolStripMenuItem1.Size = New System.Drawing.Size(214, 22)
        Me.RoomInformationToolStripMenuItem1.Text = "Room Information"
        '
        'SetUpUserToolStripMenuItem
        '
        Me.SetUpUserToolStripMenuItem.Name = "SetUpUserToolStripMenuItem"
        Me.SetUpUserToolStripMenuItem.Size = New System.Drawing.Size(259, 22)
        Me.SetUpUserToolStripMenuItem.Text = "Set Up User"
        '
        'ChangeUserNamePasswordToolStripMenuItem
        '
        Me.ChangeUserNamePasswordToolStripMenuItem.Name = "ChangeUserNamePasswordToolStripMenuItem"
        Me.ChangeUserNamePasswordToolStripMenuItem.Size = New System.Drawing.Size(259, 22)
        Me.ChangeUserNamePasswordToolStripMenuItem.Text = "Change User Name/Password"
        '
        'RoomInformationToolStripMenuItem
        '
        Me.RoomInformationToolStripMenuItem.Name = "RoomInformationToolStripMenuItem"
        Me.RoomInformationToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.RoomInformationToolStripMenuItem.Text = "Set Room Price"
        '
        'CustomerInformationToolStripMenuItem
        '
        Me.CustomerInformationToolStripMenuItem.Name = "CustomerInformationToolStripMenuItem"
        Me.CustomerInformationToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.CustomerInformationToolStripMenuItem.Text = "Customer Information"
        '
        'BookingToolStripMenuItem2
        '
        Me.BookingToolStripMenuItem2.Name = "BookingToolStripMenuItem2"
        Me.BookingToolStripMenuItem2.Size = New System.Drawing.Size(147, 22)
        Me.BookingToolStripMenuItem2.Text = "Booking"
        '
        'CheckOutToolStripMenuItem
        '
        Me.CheckOutToolStripMenuItem.Name = "CheckOutToolStripMenuItem"
        Me.CheckOutToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.CheckOutToolStripMenuItem.Text = "Check Out"
        '
        'CheckInToolStripMenuItem2
        '
        Me.CheckInToolStripMenuItem2.Name = "CheckInToolStripMenuItem2"
        Me.CheckInToolStripMenuItem2.Size = New System.Drawing.Size(147, 22)
        Me.CheckInToolStripMenuItem2.Text = "Check In"
        '
        'BookingToolStripMenuItem1
        '
        Me.BookingToolStripMenuItem1.Name = "BookingToolStripMenuItem1"
        Me.BookingToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.BookingToolStripMenuItem1.Text = "Booking"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ViewAllRoomToolStripMenuItem
        '
        Me.ViewAllRoomToolStripMenuItem.Name = "ViewAllRoomToolStripMenuItem"
        Me.ViewAllRoomToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ViewAllRoomToolStripMenuItem.Text = "View All Room"
        '
        'CheckInToolStripMenuItem
        '
        Me.CheckInToolStripMenuItem.Name = "CheckInToolStripMenuItem"
        Me.CheckInToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.CheckInToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.CheckInToolStripMenuItem.Text = "Check In"
        '
        'BookingToolStripMenuItem
        '
        Me.BookingToolStripMenuItem.Name = "BookingToolStripMenuItem"
        Me.BookingToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.BookingToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.BookingToolStripMenuItem.Text = "Booking"
        '
        'CheckOutToolStripMenuItem1
        '
        Me.CheckOutToolStripMenuItem1.Name = "CheckOutToolStripMenuItem1"
        Me.CheckOutToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.CheckOutToolStripMenuItem1.Size = New System.Drawing.Size(192, 22)
        Me.CheckOutToolStripMenuItem1.Text = "Check Out"
        '
        'CheckInToolStripMenuItem1
        '
        Me.CheckInToolStripMenuItem1.Name = "CheckInToolStripMenuItem1"
        Me.CheckInToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.CheckInToolStripMenuItem1.Text = "Check In"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(214, 22)
        Me.ToolStripMenuItem1.Text = "Room Information"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(259, 22)
        Me.ToolStripMenuItem2.Text = "Set Up User"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(259, 22)
        Me.ToolStripMenuItem3.Text = "Change User Name/Password"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(214, 22)
        Me.ToolStripMenuItem4.Text = "Set Room Price"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(214, 22)
        Me.ToolStripMenuItem5.Text = "Customer Information"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(147, 22)
        Me.ToolStripMenuItem6.Text = "Booking"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(147, 22)
        Me.ToolStripMenuItem7.Text = "Check Out"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(147, 22)
        Me.ToolStripMenuItem8.Text = "Check In"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem9.Text = "Booking"
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(192, 22)
        Me.ToolStripMenuItem13.Text = "Check In"
        '
        'ToolStripMenuItem14
        '
        Me.ToolStripMenuItem14.Name = "ToolStripMenuItem14"
        Me.ToolStripMenuItem14.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem14.Size = New System.Drawing.Size(192, 22)
        Me.ToolStripMenuItem14.Text = "Booking"
        '
        'ToolStripMenuItem15
        '
        Me.ToolStripMenuItem15.Name = "ToolStripMenuItem15"
        Me.ToolStripMenuItem15.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem15.Size = New System.Drawing.Size(192, 22)
        Me.ToolStripMenuItem15.Text = "Check Out"
        '
        'ToolStripMenuItem16
        '
        Me.ToolStripMenuItem16.Name = "ToolStripMenuItem16"
        Me.ToolStripMenuItem16.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem16.Text = "Check In"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.TransactionToolStripMenuItem, Me.SearchToolStripMenuItem, Me.UtilityToolStripMenuItem, Me.SecurityToolStripMenuItem, Me.ReportToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(928, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAllRoomToolStripMenuItem1, Me.LogOutToolStripMenuItem1, Me.ExitToolStripMenuItem1})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'TransactionToolStripMenuItem
        '
        Me.TransactionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckInToolStripMenuItem3, Me.BookingToolStripMenuItem3, Me.CheckOutToolStripMenuItem2})
        Me.TransactionToolStripMenuItem.Name = "TransactionToolStripMenuItem"
        Me.TransactionToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.TransactionToolStripMenuItem.Text = "Transaction"
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckInToolStripMenuItem4, Me.BookingToolStripMenuItem4})
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.SearchToolStripMenuItem.Text = "Search"
        '
        'CheckInToolStripMenuItem4
        '
        Me.CheckInToolStripMenuItem4.Name = "CheckInToolStripMenuItem4"
        Me.CheckInToolStripMenuItem4.Size = New System.Drawing.Size(127, 22)
        Me.CheckInToolStripMenuItem4.Text = "Check In"
        '
        'BookingToolStripMenuItem4
        '
        Me.BookingToolStripMenuItem4.Name = "BookingToolStripMenuItem4"
        Me.BookingToolStripMenuItem4.Size = New System.Drawing.Size(127, 22)
        Me.BookingToolStripMenuItem4.Text = "Booking"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerInformationToolStripMenuItem1, Me.SetRoomPriceToolStripMenuItem, Me.RoomInformationToolStripMenuItem2})
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.UtilityToolStripMenuItem.Text = "Utility"
        '
        'CustomerInformationToolStripMenuItem1
        '
        Me.CustomerInformationToolStripMenuItem1.Name = "CustomerInformationToolStripMenuItem1"
        Me.CustomerInformationToolStripMenuItem1.Size = New System.Drawing.Size(190, 22)
        Me.CustomerInformationToolStripMenuItem1.Text = "Customer Information"
        '
        'SetRoomPriceToolStripMenuItem
        '
        Me.SetRoomPriceToolStripMenuItem.Name = "SetRoomPriceToolStripMenuItem"
        Me.SetRoomPriceToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.SetRoomPriceToolStripMenuItem.Text = "Set Room Price"
        '
        'RoomInformationToolStripMenuItem2
        '
        Me.RoomInformationToolStripMenuItem2.Name = "RoomInformationToolStripMenuItem2"
        Me.RoomInformationToolStripMenuItem2.Size = New System.Drawing.Size(190, 22)
        Me.RoomInformationToolStripMenuItem2.Text = "Room Information"
        '
        'SecurityToolStripMenuItem
        '
        Me.SecurityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetUpUserToolStripMenuItem1, Me.ChangeUserNamePasswordToolStripMenuItem1})
        Me.SecurityToolStripMenuItem.Name = "SecurityToolStripMenuItem"
        Me.SecurityToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.SecurityToolStripMenuItem.Text = "Security"
        '
        'ChangeUserNamePasswordToolStripMenuItem1
        '
        Me.ChangeUserNamePasswordToolStripMenuItem1.Name = "ChangeUserNamePasswordToolStripMenuItem1"
        Me.ChangeUserNamePasswordToolStripMenuItem1.Size = New System.Drawing.Size(227, 22)
        Me.ChangeUserNamePasswordToolStripMenuItem1.Text = "Change User Name/Password"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckInToolStripMenuItem5, Me.BookingToolStripMenuItem5, Me.CheckOutToolStripMenuItem3})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'CheckInToolStripMenuItem5
        '
        Me.CheckInToolStripMenuItem5.Name = "CheckInToolStripMenuItem5"
        Me.CheckInToolStripMenuItem5.Size = New System.Drawing.Size(135, 22)
        Me.CheckInToolStripMenuItem5.Text = "Check In"
        '
        'BookingToolStripMenuItem5
        '
        Me.BookingToolStripMenuItem5.Name = "BookingToolStripMenuItem5"
        Me.BookingToolStripMenuItem5.Size = New System.Drawing.Size(135, 22)
        Me.BookingToolStripMenuItem5.Text = "Booking"
        '
        'CheckOutToolStripMenuItem3
        '
        Me.CheckOutToolStripMenuItem3.Name = "CheckOutToolStripMenuItem3"
        Me.CheckOutToolStripMenuItem3.Size = New System.Drawing.Size(135, 22)
        Me.CheckOutToolStripMenuItem3.Text = "Check Out"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripButton3, Me.ToolStripSeparator1, Me.ToolStripButton4, Me.ToolStripButton5, Me.ToolStripSeparator2, Me.ToolStripButton6, Me.ToolStripButton7, Me.ToolStripSeparator3, Me.TDate, Me.ToolStripLabel1, Me.TUser})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(928, 25)
        Me.ToolStrip1.TabIndex = 3
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(103, 22)
        Me.ToolStripLabel1.Text = "                                "
        '
        'Timer1
        '
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 452)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(928, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Image = Global.Hotel_Management_System.My.Resources.Resources.Customer2
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(69, 22)
        Me.ToolStripButton1.Text = "Check In"
        Me.ToolStripButton1.ToolTipText = "Check In"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.Image = Global.Hotel_Management_System.My.Resources.Resources.file_tmp1
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(64, 22)
        Me.ToolStripButton2.Text = "Booking"
        Me.ToolStripButton2.ToolTipText = "Booking"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.Image = Global.Hotel_Management_System.My.Resources.Resources.Check1
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(77, 22)
        Me.ToolStripButton3.Text = "Check Out"
        Me.ToolStripButton3.ToolTipText = "Check Out"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.Image = Global.Hotel_Management_System.My.Resources.Resources.kghostview1
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(93, 22)
        Me.ToolStripButton4.Text = "View All Room"
        Me.ToolStripButton4.ToolTipText = "View All Room"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.Image = Global.Hotel_Management_System.My.Resources.Resources.Userexplore1
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(84, 22)
        Me.ToolStripButton5.Text = "Set Up User"
        Me.ToolStripButton5.ToolTipText = "Set Up User"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.Image = Global.Hotel_Management_System.My.Resources.Resources.Log_Off1
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(65, 22)
        Me.ToolStripButton6.Text = "Log Out"
        Me.ToolStripButton6.ToolTipText = "Log Out"
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.Image = Global.Hotel_Management_System.My.Resources.Resources.Switch_User1
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(45, 22)
        Me.ToolStripButton7.Text = "Exit"
        Me.ToolStripButton7.ToolTipText = "Exit"
        '
        'TDate
        '
        Me.TDate.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TDate.ForeColor = System.Drawing.Color.Black
        Me.TDate.Image = Global.Hotel_Management_System.My.Resources.Resources.CLOCK
        Me.TDate.Name = "TDate"
        Me.TDate.Size = New System.Drawing.Size(96, 22)
        Me.TDate.Text = "ToolStripLabel1"
        '
        'TUser
        '
        Me.TUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.TUser.ForeColor = System.Drawing.Color.Black
        Me.TUser.Image = Global.Hotel_Management_System.My.Resources.Resources.group
        Me.TUser.Name = "TUser"
        Me.TUser.Size = New System.Drawing.Size(96, 22)
        Me.TUser.Text = "ToolStripLabel2"
        '
        'ViewAllRoomToolStripMenuItem1
        '
        Me.ViewAllRoomToolStripMenuItem1.Image = Global.Hotel_Management_System.My.Resources.Resources.kghostview
        Me.ViewAllRoomToolStripMenuItem1.Name = "ViewAllRoomToolStripMenuItem1"
        Me.ViewAllRoomToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.ViewAllRoomToolStripMenuItem1.Text = "View All Room"
        '
        'LogOutToolStripMenuItem1
        '
        Me.LogOutToolStripMenuItem1.Image = Global.Hotel_Management_System.My.Resources.Resources.Log_Off
        Me.LogOutToolStripMenuItem1.Name = "LogOutToolStripMenuItem1"
        Me.LogOutToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.LogOutToolStripMenuItem1.Text = "Log Out"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Image = Global.Hotel_Management_System.My.Resources.Resources.Switch_User1
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'CheckInToolStripMenuItem3
        '
        Me.CheckInToolStripMenuItem3.Image = Global.Hotel_Management_System.My.Resources.Resources.Customer
        Me.CheckInToolStripMenuItem3.Name = "CheckInToolStripMenuItem3"
        Me.CheckInToolStripMenuItem3.Size = New System.Drawing.Size(135, 22)
        Me.CheckInToolStripMenuItem3.Text = "Check In"
        '
        'BookingToolStripMenuItem3
        '
        Me.BookingToolStripMenuItem3.Image = Global.Hotel_Management_System.My.Resources.Resources.file_tmp
        Me.BookingToolStripMenuItem3.Name = "BookingToolStripMenuItem3"
        Me.BookingToolStripMenuItem3.Size = New System.Drawing.Size(135, 22)
        Me.BookingToolStripMenuItem3.Text = "Booking"
        '
        'CheckOutToolStripMenuItem2
        '
        Me.CheckOutToolStripMenuItem2.Image = Global.Hotel_Management_System.My.Resources.Resources.Check
        Me.CheckOutToolStripMenuItem2.Name = "CheckOutToolStripMenuItem2"
        Me.CheckOutToolStripMenuItem2.Size = New System.Drawing.Size(135, 22)
        Me.CheckOutToolStripMenuItem2.Text = "Check Out"
        '
        'SetUpUserToolStripMenuItem1
        '
        Me.SetUpUserToolStripMenuItem1.Image = Global.Hotel_Management_System.My.Resources.Resources.Userexplore
        Me.SetUpUserToolStripMenuItem1.Name = "SetUpUserToolStripMenuItem1"
        Me.SetUpUserToolStripMenuItem1.Size = New System.Drawing.Size(227, 22)
        Me.SetUpUserToolStripMenuItem1.Text = "Set Up User"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Hotel_Management_System.My.Resources.Resources.BackGround
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(928, 474)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main"
        Me.Text = "Hotel Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RoomInformationToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetUpUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeUserNamePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RoomInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewAllRoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckOutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem14 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem16 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewAllRoomToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckOutToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerInformationToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetRoomPriceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RoomInformationToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SecurityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetUpUserToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeUserNamePasswordToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckInToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BookingToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckOutToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents TDate As System.Windows.Forms.ToolStripLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TUser As System.Windows.Forms.ToolStripLabel
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
End Class
