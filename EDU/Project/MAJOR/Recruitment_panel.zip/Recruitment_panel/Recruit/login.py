from django.http import HttpResponse
from django.shortcuts import render, redirect
from Recruit.forms import requirement_statisticsForm
from Recruit.models import requirement_statistics