function myFunction(x) {
  x.style.background = "yellow";
}
